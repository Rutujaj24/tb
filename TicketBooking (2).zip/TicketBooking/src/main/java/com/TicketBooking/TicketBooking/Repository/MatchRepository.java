package com.TicketBooking.TicketBooking.Repository;

import com.TicketBooking.TicketBooking.Entity.IplMatch;
import jakarta.persistence.metamodel.SingularAttribute;
import org.springframework.data.jpa.domain.AbstractPersistable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.io.Serializable;
import java.util.Optional;

public interface MatchRepository extends JpaRepository<IplMatch, Long> {

}
