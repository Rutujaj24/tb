package com.TicketBooking.TicketBooking.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "ipl_match")
public class IplMatch {

//    id
//            matchDate
//    stadium
//            teamA
//    teamB
//            ticketPrice
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id ;

    @Column(name = "matchDate")
    private LocalDate matchDate;

    @ManyToOne
    @JoinColumn(name = "stadium_id" )

    private Stadium stadium;

    @Column(name = "team_a")
    private String teamA;

    @Column(name = "team_b")
    private String teamB;

    @Column(name = "ticketPrice")
    private int ticketPrice;

    public IplMatch(int ticketPrice, String teamB, String teamA, Stadium stadium, LocalDate matchDate, Long id) {
        this.ticketPrice = ticketPrice;
        this.teamB = teamB;
        this.teamA = teamA;
        this.stadium = stadium;
        this.matchDate = matchDate;
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(LocalDate matchDate) {
        this.matchDate = matchDate;
    }

    public Stadium getStadium() {
        return stadium;
    }

    public void setStadium(Stadium stadium) {
        this.stadium = stadium;
    }

    public String getTeamA() {
        return teamA;
    }

    public void setTeamA(String teamA) {
        this.teamA = teamA;
    }

    public String getTeamB() {
        return teamB;
    }

    public void setTeamB(String teamB) {
        this.teamB = teamB;
    }

    public int getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(int ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public IplMatch() {
    }

    @Override
    public String toString() {
        return "IplMatch{" +
                "id=" + id +
                ", matchDate=" + matchDate +
                ", stadium='" + stadium + '\'' +
                ", teamA='" + teamA + '\'' +
                ", teamB='" + teamB + '\'' +
                ", ticketPrice=" + ticketPrice +
                '}';
    }
}
