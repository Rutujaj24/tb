package com.TicketBooking.TicketBooking.Service;

import com.TicketBooking.TicketBooking.Entity.Stadium;
import com.TicketBooking.TicketBooking.Repository.StadiumRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StadiumServiceImpl implements StadiumService{
    private StadiumRepository stadiumRepository;

    @Autowired
    public StadiumServiceImpl(StadiumRepository stadiumRepository) {
        this.stadiumRepository = stadiumRepository;
    }



    @Override
    public List<Stadium> findAll() {
        return stadiumRepository.findAll() ;
    }

    @Override
    public Stadium findById(Long Id) {
        return stadiumRepository.findById(Id).orElseThrow(()->new RuntimeException("Stadium not Found"));
    }

    @Override
    public Stadium save(Stadium stadium) {
        return stadiumRepository.save(stadium);
    }

    @Override
    public void deleteById(Long id) {

        stadiumRepository.deleteById(id);
    }
}
