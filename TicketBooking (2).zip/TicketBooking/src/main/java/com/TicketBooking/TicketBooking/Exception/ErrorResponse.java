package com.TicketBooking.TicketBooking.Exception;

import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

public class ErrorResponse {
    private int status;
    private String message;
    private LocalDateTime timestamp;
    private HttpStatus Httpstatus;

    public ErrorResponse(int status, String message, LocalDateTime timestamp, HttpStatus httpstatus) {
        this.status = status;
        this.message = message;
        this.timestamp = timestamp;
        Httpstatus = httpstatus;
    }

    public ErrorResponse() {

    }

    public int getStatus() {
        return status;
    }




    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    

    public HttpStatus getHttpstatus() {
        return Httpstatus;
    }

    public void setHttpstatus(HttpStatus httpstatus) {
        Httpstatus = httpstatus;
    }

    public void setStatus(HttpStatus httpStatus) {
    }

    public void setTimestamp(long l) {

    }
}
