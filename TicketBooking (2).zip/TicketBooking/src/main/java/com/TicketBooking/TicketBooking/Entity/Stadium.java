package com.TicketBooking.TicketBooking.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Stadium")
public class Stadium {
//    id
//            name
//    matches
//            location
//    capacity
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id = null;

    @Column(name = "name")
    private String name;

    @OneToMany(mappedBy = "stadium" , cascade = CascadeType.PERSIST, orphanRemoval = true)

    private List<IplMatch> iplMatches ;



    @Column(name = "location")
    private String location;


    @Column(name = "capacity")
    private int capacity;

    @Version
    private Long version;

    public Stadium(Long id, String name, List<IplMatch> iplMatches, String location, int capacity) {
        this.id = id;
        this.name = name;
        this.iplMatches = iplMatches;
        this.location = location;
        this.capacity = capacity;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<IplMatch> getIplMatches() {
        return iplMatches;
    }

    public void setIplMatches(List<IplMatch> iplMatches) {
        this.iplMatches = iplMatches;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Stadium{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", iplMatches=" + iplMatches +
                ", location='" + location + '\'' +
                ", capacity=" + capacity +
                '}';
    }

    public Stadium() {
    }

    public Long getVersion() {
        return version;
    }


    public void setVersion(Long version) {
        this.version = version;
    }

    public Stadium(Long id, String name, List<IplMatch> iplMatches, String location, int capacity, Long version) {
        this.id = id;
        this.name = name;
        this.iplMatches = iplMatches;
        this.location = location;
        this.capacity = capacity;
        this.version = version;
    }
}
