package com.TicketBooking.TicketBooking.Repository;

import com.TicketBooking.TicketBooking.Entity.Stadium;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StadiumRepository extends JpaRepository<Stadium, Long> {

}
