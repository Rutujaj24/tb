package com.TicketBooking.TicketBooking.Service;

import com.TicketBooking.TicketBooking.Entity.IplMatch;

import java.util.List;

public interface IplMatchService {
    List<IplMatch> findAll();

    IplMatch findById(Long Id);

    IplMatch save( IplMatch iplMatch);

    void deleteById(Long id);

}
