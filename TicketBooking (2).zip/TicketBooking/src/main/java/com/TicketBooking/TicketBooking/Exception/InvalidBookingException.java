package com.TicketBooking.TicketBooking.Exception;

public class InvalidBookingException extends RuntimeException{
    public InvalidBookingException(String message) {
        super(message);
    }
}
