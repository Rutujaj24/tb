package com.TicketBooking.TicketBooking.Controller;

import com.TicketBooking.TicketBooking.Entity.Stadium;
import com.TicketBooking.TicketBooking.Repository.StadiumRepository;
import com.TicketBooking.TicketBooking.Service.StadiumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/stadium")
public class StadiumController {

    private StadiumService stadiumService;
    @Autowired
    public StadiumController(StadiumService stadiumService) {
        this.stadiumService = stadiumService;
    }

    @GetMapping
    public List<Stadium> getStadium(){
        return stadiumService.findAll();
    }





}
