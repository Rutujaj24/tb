package com.TicketBooking.TicketBooking.Service;

import com.TicketBooking.TicketBooking.Entity.IplMatch;
import com.TicketBooking.TicketBooking.Exception.MatchNotFoundException;
import com.TicketBooking.TicketBooking.Repository.MatchRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IplServiceImpl implements IplMatchService{
    private MatchRepository matchRepository;
    @Autowired
    public IplServiceImpl(MatchRepository matchRepository) {
        this.matchRepository = matchRepository;
    }


    @Override
    public List<IplMatch> findAll() {
        return matchRepository.findAll();
    }

    @Override
    public IplMatch findById(Long id) {
        return matchRepository.findById(id).orElseThrow(()-> new MatchNotFoundException("Match Not Found"));
    }

    @Override
//    @Transactional
    public IplMatch save(IplMatch iplMatch) {
        return matchRepository.save(iplMatch);
    }

    @Override
    public void deleteById(Long id) {
matchRepository.deleteById(id);
    }
}
