package com.TicketBooking.TicketBooking.Exception;

public class StadiumFullException extends RuntimeException{
    public StadiumFullException(String message) {
        super(message);
    }
}
