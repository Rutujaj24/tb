package com.TicketBooking.TicketBooking.Service;

import com.TicketBooking.TicketBooking.Entity.IplMatch;
import com.TicketBooking.TicketBooking.Entity.Stadium;

import java.util.List;

public interface StadiumService  {
    List<Stadium> findAll();

    Stadium findById(Long Id);

   Stadium save( Stadium stadium);

    void deleteById(Long id);

}

