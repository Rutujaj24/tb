package com.TicketBooking.TicketBooking.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "TicketBooking")
public class TicketBooking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @OneToOne
    @JoinColumn(name = "match_id", nullable = false)
    private IplMatch iplMatch;

    @Column(name = "number_of_seats")
    private int numberOfSeats;

    @Column(name = "total_amount")
    private int totalAmount;

    public TicketBooking(Long id, User user, IplMatch iplMatch, int numberOfSeats, int totalAmount) {
        this.id = id;
        this.user = user;
        this.iplMatch = iplMatch;
        this.numberOfSeats = numberOfSeats;
        this.totalAmount = totalAmount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public IplMatch getIplMatch() {
        return iplMatch;
    }

    public void setIplMatch(IplMatch iplMatch) {
        this.iplMatch = iplMatch;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public TicketBooking() {
    }

    @Override
    public String toString() {
        return "TicketBooking{" +
                "id=" + id +
                ", user=" + user +
                ", iplMatch=" + iplMatch +
                ", numberOfSeats=" + numberOfSeats +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
