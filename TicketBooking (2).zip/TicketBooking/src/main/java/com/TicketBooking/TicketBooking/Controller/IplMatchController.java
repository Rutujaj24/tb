package com.TicketBooking.TicketBooking.Controller;

import com.TicketBooking.TicketBooking.Entity.IplMatch;
import com.TicketBooking.TicketBooking.Service.IplMatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/iplmatch")
public class IplMatchController {
    private IplMatchService iplMatchService;
     @Autowired
    public IplMatchController(IplMatchService iplMatchService) {
        this.iplMatchService = iplMatchService;
    }

    @GetMapping
    public List<IplMatch> getAllMatches(){
         return iplMatchService.findAll();
    }


    @GetMapping("/{id}")
    public IplMatch getMatch(@PathVariable Long id){
        return iplMatchService.findById(id);
    }


    @PostMapping
    public IplMatch saveMatch(@RequestBody IplMatch iplMatch){
         return iplMatchService.save(iplMatch);
    }
    @DeleteMapping("/{id}")
    public void deleteMatch(@PathVariable Long id){
         iplMatchService.deleteById(id);
    }


}
